
/// The Crane class
/**
 * @author FVelasco
 * 
 * @param parameters = {
 *      craneHeight: <float>,
 *      craneWidth : <float>,
 *      material: <Material>
 * }
 */



Crane = function (parameters) {
  THREE.Object3D.call (this);
  
  // class variables
  Crane.WORLD = 0;
  Crane.LOCAL = 1;
  
  // private attributes
  
  var craneHeight = (parameters.craneHeight === undefined ? 30 : parameters.craneHeight);
  var craneWidth  = (parameters.craneWidth === undefined ? 45 : parameters.craneWidth);
  var material    = (parameters.material === undefined ? new THREE.MeshPhongMaterial ({color: 0xffffff}) : parameters.material);
        
  // With these variables, the posititon of the hook is set
  var angle           = 0;
  var distance        = craneWidth / 2;
  var height          = craneHeight / 2;
  
  // Height of different parts
  var baseHookHeight = craneHeight/100;
  var trolleyHeight  = craneWidth/20;
  
  // Objects for operating with the crane
  var jib          = null;
  var trolley      = null;
  var string       = null;
  var stringLength = 1;
  var hook         = null;
  var box          = null;
  
  // Limits
  var distanceMin  = craneWidth/7;
  var distanceMax  = 0.75*craneWidth;
  var heightMin    = 0;
  var heightMax    = 0.9*craneHeight;
  
  // Initializer
  var init = function (self) {
    self.add (createBase());
  }
  
  // Private methods
  
  /// It computes the length of the string
  var computeStringLength = function () {
    // stringLenght = base height + crane height - trolley height - hook height - height of the hook to the ground. So,
    // stringLength = baseHookHeight + craneHeight - trolleyHeight - baseHookHeight - height;
    return craneHeight - trolleyHeight - height;
  }
  
  /// It creates the base and adds the mast to the base
  var createBase = function () {
    var base = new THREE.Mesh (
      new THREE.CylinderGeometry (craneWidth/10, craneWidth/10, baseHookHeight, 16, 1), 
      material);
    base.geometry.applyMatrix (new THREE.Matrix4().makeTranslation (0, baseHookHeight/2, 0));
    base.castShadow = true;
    base.autoUpdateMatrix = false;
    base.name = "crane";
    base.add(createMast());
    return base;
  }
  
  /// It creates the mast and adds the jib to the mast
  var createMast = function () {
    var mast = new THREE.Mesh (
      new THREE.CylinderGeometry (craneWidth/20, craneWidth/20, craneHeight, 16, 8), material);
    mast.geometry.applyMatrix (new THREE.Matrix4().makeTranslation (0, craneHeight/2, 0));
    mast.castShadow = true;
    mast.position.y = baseHookHeight;
    mast.autoUpdateMatrix = false;
    mast.updateMatrix();
    mast.name = "crane";
    mast.add(createJib());
    return mast;
  }
  
  /// It creates the jib, and adds the trolley-string-hook group to the jib
  var createJib = function () {
    jib = new THREE.Mesh (
      new THREE.BoxGeometry (craneWidth, craneWidth/10, craneWidth/10),
      material);
    jib.geometry.applyMatrix (new THREE.Matrix4().makeTranslation (0.3*craneWidth, craneWidth/20, 0));
    jib.castShadow = true;
    jib.position.y = craneHeight;
    jib.rotation.y = angle;
    jib.add (createTrolleyStringHook());

    return jib;
  }
  

  /// It creates the trolley, string and hook
  var createTrolleyStringHook = function () {
    trolley = new THREE.Mesh (
      new THREE.BoxGeometry (craneWidth/10, trolleyHeight, craneWidth/10),
      material);
    trolley.geometry.applyMatrix (new THREE.Matrix4().makeTranslation (0, trolleyHeight/2, 0));
    trolley.castShadow = true;
    trolley.position.y = -trolleyHeight;
    trolley.position.x = distanceMin;
    
    string = new THREE.Mesh (
      new THREE.CylinderGeometry (craneWidth/100, craneWidth/100, 1), material);
    string.geometry.applyMatrix (new THREE.Matrix4().makeTranslation (0, -0.5, 0));
    string.castShadow = true;
    stringLength = computeStringLength();
    string.scale.y = stringLength;
    trolley.add (string);
    
    hook = new THREE.Mesh (
      new THREE.CylinderGeometry (craneWidth/40, craneWidth/40, baseHookHeight, 16, 1),
      material);
    hook.geometry.applyMatrix (new THREE.Matrix4().makeTranslation (0, -baseHookHeight/2, 0));
    hook.castShadow = true;
    hook.position.y = -stringLength;
    hook.name = "crane";
    trolley.add (hook);
    
    return trolley;
  }
  
  /// It sets the angle of the jib
  /**
   * @param anAngle - The angle of the jib
   */
  var setJib = function (anAngle) {
    angle = anAngle;
    jib.rotation.y = angle;    
  }
  
  /// It sets the distance of the trolley from the mast
  /**
   * @param aDistance - The distance of the trolley from the mast
   */
  var setTrolley = function (aDistance) {
    if (distanceMin <= aDistance && aDistance <= distanceMax) {
      distance = aDistance;
      trolley.position.x = distance;
    }
  }
  
  /// It sets the distance of the hook from the bottom of the base
  /**
   * @param aHeight - The distance of the hook from the bottom of the base
   */
  var setHook = function (aHeight) {
    if (heightMin <= aHeight && aHeight <= heightMax) {
      height = aHeight;
      stringLength = computeStringLength ()
      string.scale.y = stringLength;
      hook.position.y = -stringLength;
    }
  }
  
  // public methods
  
  /// It sets the hook according to
  /**
   * @param anAngle - The angle of the jib
   * @param aDistance - The distance of the trolley from the mast
   * @param aHeight - The distance of the hook from the bottom of the base
   */
  this.setHookPosition = function (anAngle, aDistance, aHeight) {
    setJib (anAngle);
    setTrolley (aDistance);
    setHook (aHeight);
  }
  
  /// It returns the position of the hook
  /**
   * @param world - Whether the returned position is referenced to the World Coordinates System (Crane.WORLD) or is referenced to the crane position (Crane.LOCAL)
   * @return A Vector3 with the asked position
   */
  this.getHookPosition = function (world) {
    if (world === undefined)
      world = Crane.WORLD;
    var hookPosition = new THREE.Vector3();
    hookPosition.setFromMatrixPosition (hook.matrixWorld);
    hookPosition.y -= baseHookHeight;
    if (world === Crane.LOCAL) {
      var cranePosition = new THREE.Vector3();
      cranePosition.setFromMatrixPosition (this.matrixWorld);
      hookPosition.sub (cranePosition);
    }
    return hookPosition;
  }
  
  /// The crane takes a box
  /**
   * @param aBox - The box to be taken
   * @return The new height of the hook, on the top of the box. Zero if no box is taken
   */
  this.takeBox = function (aBox) { 
    if (box === null) {
      box = aBox;
      newHeight = box.position.y + box.geometry.parameters.height;
      heightMin = box.geometry.parameters.height;
      box.position.x = 0;
      box.position.y = -box.geometry.parameters.height-baseHookHeight;
      box.position.z = 0;
      box.rotation.y -= jib.rotation.y;
      hook.add (box);
      return newHeight;
    }
    return 0;
  }
  
  /// The crane drops its taken box
  /**
   * @return The dropped box, or null if no box is dropped.
   */
  this.dropBox = function () {
    if (box !== null) {
      var theBox = box;
      hook.remove (box);
      box = null;
      theBox.rotation.y += jib.rotation.y;
      heightMin = 0;
      return theBox;
    } else
      return null;
  }
  
  // Constructor
  init (this);
}

Crane.prototype = Object.create (THREE.Object3D.prototype);
Crane.prototype.constructor = Crane;
