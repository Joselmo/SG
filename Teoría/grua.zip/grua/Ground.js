
/// The Ground class
/**
 * @author FVelasco
 * 
 * @param aWidth - The width of the ground
 * @param aDeep - The deep of the ground
 * @param aMaterial - The material of the ground
 * @param aBoxSize - The size for the boxes
 */

Ground = function (aWidth, aDeep, aMaterial, aBoxSize) {
  THREE.Object3D.call (this);
  
  // Private attributes
  
  var width = aWidth;
  var deep = aDeep;
  var material = aMaterial;
  var boxSize = aBoxSize;
  
  var ground = null;
  var boxes  = null;
  
  var box    = null;
  var raycaster = new THREE.Raycaster ();
  
  
  // Initializer
  var init = function (self) {
    ground = new THREE.Mesh (
      new THREE.BoxGeometry (width, 0.2, deep, 1, 1, 1),
      material);
    ground.applyMatrix (new THREE.Matrix4().makeTranslation (0,-0.1,0));
    ground.receiveShadow = true;
    ground.autoUpdateMatrix = false;
    self.add (ground);
    
    boxes = new THREE.Object3D();
    self.add (boxes);
  }
  
  // Private methods
  
  /// Whether the boxes b1 and b2 intersect or not
  /**
   * @param b1 - A box to test
   * @param b2 - Other box to test
   * @return True if b1 and b2 intersect
   */
  var intersectBoxes = function (b1, b2) {
    var vectorBetweenBoxes = new THREE.Vector2();
    vectorBetweenBoxes.subVectors (new THREE.Vector2 (b1.position.x, b1.position.z),
                                   new THREE.Vector2 (b2.position.x, b2.position.z));
    return (vectorBetweenBoxes.length() < boxSize);
  }
  
  /// It returns the position of the mouse in normalized coordinates ([-1,1],[-1,1])
  /**
   * @param event - Mouse information
   * @return A Vector2 with the normalized mouse position
   */
  var getMouse = function (event) {
    var mouse = new THREE.Vector2 ();
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = 1 - 2 * (event.clientY / window.innerHeight);
    return mouse;
  }
  
  /// It returns the point on the ground where the mouse has clicked
  /**
   * @param event - The mouse information
   * @return The Vector2 with the ground point clicked, or null
   */
  var getPointOnGround = function (event) {
    var mouse = getMouse (event);
    raycaster.setFromCamera (mouse, scene.getCamera());
    var surfaces = [ground];
    var pickedObjects = raycaster.intersectObjects (surfaces);
    if (pickedObjects.length > 0) {
      return new THREE.Vector2 (pickedObjects[0].point.x, pickedObjects[0].point.z);
    } else
      return null;
  }
  
  /// It computes the height of the boxes so that some can be stacked on the others
  /**
   * @param k - From which box must be calculated
   */
  var updateHeightBoxes = function (k) {
    for (var i = k; i < boxes.children.length; i++) {
      boxes.children[i].position.y = 0;
      for (var j = 0; j < i; j++) {
        if (intersectBoxes (boxes.children[j], boxes.children[i])) {
          boxes.children[i].position.y = boxes.children[j].position.y + 
            boxes.children[j].geometry.parameters.height;
        }
      }
    }
  }
  
  // Public methods
  
  /// It adds a new box on the ground
  /**
   * @param event - Mouse information
   * @param action - Which action is going to be processed: start adding or finish.
   */
  this.addBox = function (event, action) {
    if (action === TheScene.END_ACTION && box !== null) {
      box = null;
      return;
    }
    var pointOnGround = getPointOnGround (event);

    if (pointOnGround !== null) {
      if (action === TheScene.NEW_BOX) {
        box = new THREE.Mesh (
          new THREE.BoxGeometry (boxSize, boxSize, boxSize), 
          new THREE.MeshPhongMaterial ({color: Math.floor (Math.random()*16777215)}));
        box.geometry.applyMatrix (new THREE.Matrix4().makeTranslation (0, boxSize/2, 0));
        box.position.x = pointOnGround.x;
        box.position.y = 0;
        box.position.z = pointOnGround.y;
        box.receiveShadow = true;
        box.castShadow = true;
        box.name = 'box';
        boxes.add (box);
        updateHeightBoxes(boxes.children.length-1);
      }
    }
  }
  
  /// It moves or rotates a box on the ground
  /**
   * @param event - Mouse information
   * @param action - Which action is going to be processed: select a box, move it, rotate it or finish the action.
   */
  this.moveBox = function (event, action) {
    switch (action) {
      case TheScene.END_ACTION :
        if (box !== null) {
          box.material.transparent = false;
          box = null;
        }
        break;
        
      case TheScene.MOVE_BOX :
        var pointOnGround = getPointOnGround (event);
        if (pointOnGround !== null) {
          if (box !== null) {
            box.position.x = pointOnGround.x;
            box.position.z = pointOnGround.y;
            updateHeightBoxes(boxes.children.length-1);
          }
        }
        break;
        
      case TheScene.SELECT_BOX :
        var mouse = getMouse (event);
        raycaster.setFromCamera (mouse, scene.getCamera());
        var pickedObjects = raycaster.intersectObjects (boxes.children);
        if (pickedObjects.length > 0) {
          box = pickedObjects[0].object;
          box.material.transparent = true;
          box.material.opacity = 0.7;
          indexOfBox = boxes.children.indexOf (box);
          boxes.remove (box);
          boxes.add (box);
          updateHeightBoxes(indexOfBox);
        }
        break;
        
      case TheScene.ROTATE_BOX :
        if (box !== null) {
          // Chrome and other use wheelDelta, Firefox uses detail
          box.rotation.y += (event.wheelDelta ? event.wheelDelta/20 : -event.detail);
        }
        break;
    }
  }
  
  /// The crane can take a box
  /**
   * @param position The position where the crane's hook is
   * @return The box to be taken, or null
   */
  this.takeBox = function (position) {
    if (boxes.children.length === 0) // There is no boxes
      return null;
    var minDistance = position.distanceToSquared (boxes.children[0].position);
    var nearestBox = 0;
    var distance = 0;
    for (var i = 1; i < boxes.children.length; i++) {
      distance = position.distanceToSquared (boxes.children[i].position);
      if (distance < minDistance) {
        minDistance = distance;
        nearestBox = i;
      }
    }
    if (minDistance < boxSize*boxSize) {
      var boxCrane = boxes.children[nearestBox];
      boxes.remove (boxCrane);
      updateHeightBoxes(nearestBox);
      return boxCrane;
    }
    return null;
  }
  
  /// The crane has dropped a box
  /**
   * @param aBox - The dropped box
   */
  this.dropBox = function (aBox) {
    boxes.add (aBox);
    updateHeightBoxes(boxes.children.length-1);
  }
  
  
  // Constructor
  init (this);
}

Ground.prototype = Object.create (THREE.Object3D.prototype);
Ground.prototype.constructor = Ground;
