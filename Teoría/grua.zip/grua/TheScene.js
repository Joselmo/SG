
/// The Model Facade class. The root node of the graph.
/**
 * @param renderer - The renderer to visualize the scene
 */
TheScene = function (renderer) {
  THREE.Scene.call (this);
  
  // class variables
  
  // Application modes
  TheScene.NO_ACTION = 0;
  TheScene.ADDING_BOXES = 1;
  TheScene.MOVING_BOXES = 2;
  
  // Actions
  TheScene.NEW_BOX = 0;
  TheScene.MOVE_BOX = 1;
  TheScene.SELECT_BOX = 2;
  TheScene.ROTATE_BOX = 3;
  TheScene.END_ACTION = 10;
  
  // Private attributes
  
  var ambientLight = null;
  var spotLight = null;
  var camera = null;
  var trackballControls = null;
  var axis = null;
  var model = null;
  var crane = null;
  var ground = null;
  
  // Initializer
  var init = function (self, renderer) {
    createLights (self);
    createCamera (self, renderer);
    axis = new THREE.AxisHelper (25);
    self.add (axis);
    model = createModel ();
    self.add (model);
  }
  
  // Private methods
  
  /// It creates the camera and adds it to the graph
  /**
   * @param self - Root node of the graph
   * @param renderer - The renderer associated with the camera
   */
  var createCamera = function (self, renderer) {
    camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set (60, 30, 60);
    var look = new THREE.Vector3 (0,20,0);
    camera.lookAt(look);

    trackballControls = new THREE.TrackballControls (camera, renderer);
    trackballControls.rotateSpeed = 5;
    trackballControls.zoomSpeed = -2;
    trackballControls.panSpeed = 0.5;
    trackballControls.target = look;
    
    self.add(camera);
  }
  
  /// It creates lights and adds them to the graph
  /**
   * @param self - Root node of the graph
   */
  var createLights = function (self) {
    // add subtle ambient lighting
    ambientLight = new THREE.AmbientLight(0xccddee, 0.35);
    self.add (ambientLight);
    
    // add spotlight for the shadows
    spotLight = new THREE.SpotLight( 0xffffff );
    spotLight.position.set( 60, 60, 40 );
    spotLight.castShadow = true;
    self.add (spotLight);
  }
  
  /// It creates the geometric model: crane and ground
  /**
   * @return The model
   */
  var createModel = function () {
    var model = new THREE.Object3D()
    crane = new Crane({});
    model.add (crane);
    ground = new Ground (300, 300, new THREE.MeshPhongMaterial ({color: 0x00ff00}), 4);
    model.add (ground);
    return model;
  }
  
  // Public methods

  /// It adds a new box, or finish the action
  /**
   * @param event - Mouse information
   * @param action - Which action is requested to be processed: start adding or finish.
   */
  this.addBox = function (event, action) {
    ground.addBox(event, action);
  }
  
  /// It moves or rotates a box on the ground
  /**
   * @param event - Mouse information
   * @param action - Which action is requested to be processed: select a box, move it, rotate it or finish the action.
   */
  this.moveBox = function (event, action) {
    ground.moveBox (event, action);
  }
  
  /// The crane can take a box
  /**
   * @return The new height of the hook, on the top of the taken box. Zero if no box is taken
   */
  this.takeBox = function () { 
    var box = ground.takeBox (crane.getHookPosition());
    if (box === null)
      return 0; 
    else 
      return crane.takeBox (box); 
  }
  
  /// The crane drops its taken box
  this.dropBox = function () {
    var box = crane.dropBox ();
    if (box !== null) {
      box.position.copy (crane.getHookPosition());
      box.position.y = 0;
      ground.dropBox (box);
    }
  }
  
  /// It sets the crane position according to the GUI
  /**
   * @controls - The GUI information
   */
  this.animate = function (controls) {
    axis.visible = controls.axis;
    spotLight.intensity = controls.lightIntensity;
    crane.setHookPosition (controls.rotation, controls.distance, controls.height);
  }
  
  /// It returns the camera
  /**
   * @return The camera
   */
  this.getCamera = function () {
    return camera;
  }
  
  /// It returns the camera controls
  /**
   * @return The camera controls
   */
  this.getCameraControls = function () {
    return trackballControls;
  }
  
  /// It updates the aspect ratio of the camera
  /**
   * @param anAspectRatio - The new aspect ratio for the camera
   */
  this.setCameraAspect = function (anAspectRatio) {
    camera.aspect = anAspectRatio;
    camera.updateProjectionMatrix();
  }
  
  // constructor
  init (this, renderer);
}

TheScene.prototype = Object.create (THREE.Scene.prototype);
TheScene.prototype.constructor = TheScene;

